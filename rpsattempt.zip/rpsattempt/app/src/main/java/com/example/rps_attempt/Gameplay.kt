package com.example.rps_attempt

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class Gameplay : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gameplay)

    }
    object WinTracker{
    var win = 0
    var totalPlays = 0
        fun addwin(){
            this.win ++
            this.totalPlays ++
        }
        fun addLossDraw(){
            this.totalPlays ++
        }
}
 //   addwin()


    fun choose_rock(view: View){
        var text = ""
        val duration = Toast.LENGTH_SHORT
        var selection = (0..2).random();
        when(selection){
            0 -> text =  "CPU chose rock. \n It's a draw, try again."
            1 -> text =  "CPU chose paper. \n CPU wins, try again."
            2 -> text =  "CPU chose scissors. \n You win!"
        }
        val toast = Toast.makeText(applicationContext, text, duration)
        toast.show()
    }

    fun choose_paper(view: View){
        var text = ""
        val duration = Toast.LENGTH_SHORT
        var selection = (0..2).random();
        when(selection){
            0 -> text =  "CPU chose rock. \n You win!"
            1 -> text =  "CPU chose paper. \n It's a draw, try again."
            2 -> text =  "CPU chose scissors. \n CPU wins, try again"
        }
        val toast = Toast.makeText(applicationContext, text, duration)
        toast.show()
    }

    fun choose_scissors(view: View){
        var text = ""
        val duration = Toast.LENGTH_SHORT
        var selection = (0..2).random();
        when(selection){
            0 -> text =  "CPU chose rock. \n CPU wins, try again."
            1 -> text =  "CPU chose paper. \n You win!"
            2 -> text =  "CPU chose scissors. \n It's a draw, try again."
        }
        val toast = Toast.makeText(applicationContext, text, duration)
        toast.show()
    }
}
